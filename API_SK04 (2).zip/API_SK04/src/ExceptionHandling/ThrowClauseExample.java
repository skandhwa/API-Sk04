package ExceptionHandling;

public class ThrowClauseExample
{
	public static void validateAge(int a)
	{
		//if(a<18)
		//{
			System.out.println("You are not elligible to vote");
			throw new ArithmeticException ("error");
		//}
//		else
//		{
//			System.out.println("You are elligible to vote");
//		}
	}
	
	
	
	

	public static void main(String[] args) {
		
		ThrowClauseExample.validateAge(24);
		
		
		

	}

}
