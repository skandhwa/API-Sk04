package ExceptionHandling;

import java.io.FileNotFoundException;
import java.io.FileReader;

public class ThrowingCopiletimeexception {
	
	public static void validate(boolean flag) throws FileNotFoundException
	{
		if(flag==false)
		{
			FileReader f=new FileReader("D:\\Locatorsand Xpath.txt");
			throw new FileNotFoundException ("e");
			
		}
		else
		{
			System.out.println("You are elligible to access the file");
		}
	}
	
	
	
	
	

	public static void main(String[] args) throws FileNotFoundException {
		
		
		ThrowingCopiletimeexception.validate(true);
		
		
		

	}

}
