package ExceptionHandling;

public class ExceptionExamples5 {

	public static void main(String[] args) {
		
		try
		{
		int x=10/0;
		System.out.println(x);
		}
		
//		catch(Exception e)
//		{
//			System.out.println("caught with "+e);
//		}
		
		
		
		finally
		{
		
		
		
		int a=20;
		int b=a+30;
		System.out.println(b);
		}
		
		
		catch(Exception e)
		{
			System.out.println("caught with "+e);
		}
		
		

	}

}
