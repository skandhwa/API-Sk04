package ExceptionHandling;

public class ExceptionEx2 {

	public static void main(String[] args) {
		
		try
		{
		int []a= {12,34,56,77,33,99};
		System.out.println(a[7]);
		}
		
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println("caught with "+e);
		}
		
		
		
		int n=10;
		int b=20;
		int c=n+b;
		System.out.println(c);

	}

}
