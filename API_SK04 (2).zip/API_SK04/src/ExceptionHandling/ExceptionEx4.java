package ExceptionHandling;

public class ExceptionEx4 {

	public static void main(String[] args) {
		
		try
		{
		String str=null;
		int x=	str.length();
		
		System.out.println("Length of string is  "+x);
		
		
		int y=10/0;
		System.out.println(y);
		
		
		int []a= {12,34,56,77,33,99};
		System.out.println(a[7]);
		}
		
		catch(ArrayIndexOutOfBoundsException e)
		{
			
		}
		
		catch(ArithmeticException e)
		{
			
		}
		
		catch(NullPointerException e)
		{
			
		}
		
		
		
		
		

	}

}
