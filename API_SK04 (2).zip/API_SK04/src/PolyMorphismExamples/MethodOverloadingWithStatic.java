package PolyMorphismExamples;

class E1
{
//	static int cube(int x)
//	{
//		return x*x*x;
//	}
	
	static double cube(double y)
	{
	
		return y*y*y;
	}
}

public class MethodOverloadingWithStatic {

	public static void main(String[] args) {
		
	System.out.println(E1.cube(10));	
		
	//System.out.println(	E1.cube(12.5));

	}

}
