package PolyMorphismExamples;

class F4
{
	int add(int x,int y)
	{
		return x+y;
	}
	
	float add(float a,int b,int c)
	{
		return a+b;
	}
}


public class FirstFExample {

	public static void main(String[] args) {
		
		F4 obj=new F4();
	System.out.println(obj.add(12, 34));	
	System.out.println(	obj.add(23.5f,34,89));
		

	}

}
