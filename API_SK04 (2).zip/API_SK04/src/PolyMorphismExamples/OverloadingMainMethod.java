package PolyMorphismExamples;

public class OverloadingMainMethod {
	
	public static void main()
	{
		System.out.println("Hello");
	}
	
	

	public static void main(String[] args) {
		
		
		
		OverloadingMainMethod.main();
		System.out.println("Hi");
		

	}

}
