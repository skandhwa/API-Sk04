package PolyMorphismExamples;

class Bank
{
	int getROI(int x,int y)
	{
		return x+y;
	}
}

class HDFC extends Bank
{
	 int getROI(int x,int y)
	{
		return x+y;
	}
}

class Axis extends Bank
{
	int getROI(int x,int y)
	{
		return x+y;
	}
}


public class MethodOverridingExample {

	public static void main(String[] args) {
		
		Axis obj=new Axis();
	System.out.println(obj.getROI(2,5));
	
	HDFC obj1=new HDFC();
	System.out.println(obj.getROI(3,7));
		

	}

}
