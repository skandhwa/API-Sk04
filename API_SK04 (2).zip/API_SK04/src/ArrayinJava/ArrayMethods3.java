package ArrayinJava;

public class ArrayMethods3 {

	public static void main(String[] args) {
		
		char []ch= {'a','b','c','d','e'};
		
		System.out.println("The array is "+ch);
		
		String str=ch.toString();
		
		System.out.println("The string is  "+str);
		

	}

}
