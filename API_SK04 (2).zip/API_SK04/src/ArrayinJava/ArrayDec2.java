package ArrayinJava;

public class ArrayDec2 {

	public static void main(String[] args) {
		
		int a[]= {12,45,67,88};
		
		
		for(int i:a)
		{
			System.out.println(i);
		}
		
		
		
		

	}

}
