package ArrayinJava;

import java.util.Arrays;

public class ArrayComparasion {

	public static void main(String[] args) {
		
		int a[]= {92,45,67,88,100,200,900,820};
		int b[]= {92,145,67,88};
		
		String str="India";
		String []str1= {"12","13","14"};
		String []str2= {"12","13","14"};
		
		String str3="India";
		char []ch=str3.toCharArray();
		
		String str4="PndiaRepublic";
		char []ch1=str4.toCharArray();
		
		
		int y=Arrays.compare(ch,ch1);
		System.out.println("For character values are "+y);
		
		
		
		
int x=	Arrays.compare(b,a);


//Arrays.compare(a,str);
//
//System.out.println(x);

		

	}

}
