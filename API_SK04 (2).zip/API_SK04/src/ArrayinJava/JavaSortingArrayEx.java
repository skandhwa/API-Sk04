package ArrayinJava;

public class JavaSortingArrayEx {

	public static void main(String[] args) {
	
		int a[]= {12,6,4,3};
		int t=0;
		for(int i=0;i<a.length;i++)	//i=0,0<4
		{
			System.out.println(a[i]);
		}
		for(int i=0;i<a.length;i++)//i=0,0<4
		{
			for(int j=i+1;j<a.length;j++)///j=0+1=1,1<4//j=2,2<4//j=3
			{
				if(a[i]>a[j])///a[0]>a[1]///a[0]>a[2]//a[0]>a[3]
					
				{
					t=a[i];
					a[i]=a[j];
					a[j]=t;
				}
			}
		}
		
		System.out.println("Elements in sorted way are");
		
		for(int i=0;i<a.length;i++)
		{
			System.out.println(a[i]);
		}
		
		
		
		
		
		

	}

}
