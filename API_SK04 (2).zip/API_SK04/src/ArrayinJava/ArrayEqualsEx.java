package ArrayinJava;

import java.util.Arrays;

public class ArrayEqualsEx {

	public static void main(String[] args) {
		
		int a[]= {192,145,67,88};
		int b[]= {92,145,67,88};
		
		
	boolean flag=	Arrays.equals(a, b);
	System.out.println(flag);
	
	
	Arrays.sort(a);
	
	
	System.out.println("The sorted elements are");
	for(int i=0;i<a.length;i++)
	{
		System.out.println(a[i]);
	}
	
	
	
		
		

	}

}
