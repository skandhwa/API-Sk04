package ArrayinJava;

public class ArrayDec1 {

	public static void main(String[] args) {
	
		int a[]=new int [5];
		a[0]=10;
		a[1]=20;
		a[2]=30;
		a[3]=40;
		a[4]=50;
		
		for(int i=0;i<a.length;i++)///i=0,0<5,i=1,1<5
		{
			System.out.println(a[i]);///a[0]//a[1]
		}

	}

}
