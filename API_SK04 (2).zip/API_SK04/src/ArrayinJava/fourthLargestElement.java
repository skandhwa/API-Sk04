package ArrayinJava;

class Test10
{
	public static int LargestorSmallest(int a[],int n)
	{
		int t;
		for(int i=0;i<n;i++)//i=0,0<4
		{
			for(int j=i+1;j<n;j++)
			{
				if(a[i]>a[j])
					
				{
					t=a[i];
					a[i]=a[j];
					a[j]=t;
				}
			}
		}
		
		
		//return a[n-5];
		return a[5-1];
		
	}
}


public class fourthLargestElement {

	public static void main(String[] args) {
		
		int a[]= {18,6,9,4,3,22};
		int n=a.length;
	System.out.println(" largest or smallest element is "+Test10.LargestorSmallest(a,n)); 
		
		
		
		

	}

}
