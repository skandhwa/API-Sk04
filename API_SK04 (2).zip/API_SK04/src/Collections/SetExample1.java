package Collections;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class SetExample1 {

	public static void main(String[] args) {
		
		Set<String> s1=new HashSet<String>();
		s1.add("Saurabh");
		s1.add("Gaurabh");
		s1.add("Piyush");
		s1.add("Ramesh");
		s1.add("Piyush");
		
		List<Integer> li=new ArrayList<Integer>();
		li.add(23);
		li.add(45);
		li.add(99);
		li.add(23);
		li.add(45);
		li.add(99);
		li.add(23);
		li.add(45);
		li.add(99);
		
		System.out.println("Elements of list are "+li);
		
		System.out.println("Elements of set are  "+s1);
		
		

	}

}
