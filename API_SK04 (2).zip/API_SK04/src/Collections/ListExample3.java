package Collections;

import java.util.ArrayList;
import java.util.List;

public class ListExample3 {

	public static void main(String[] args) {
		
		List<Integer> li=new ArrayList<Integer>();
		li.add(12);
		li.add(45);
		li.add(99);
		//li.add(102);
		
		//li.remove(3);
		
		System.out.println(li);
		
		List<Integer> li2=new ArrayList<Integer>();
		li2.add(102);
		li2.add(145);
		li2.add(909);
		li2.add(1020);
		
		
		li.removeAll(li2);
		
		System.out.println(li);
		

	}

}
