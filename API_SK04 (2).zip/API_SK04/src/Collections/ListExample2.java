package Collections;

import java.util.ArrayList;
import java.util.List;

public class ListExample2 {

	public static void main(String[] args) {
		
		List<Object> li=new ArrayList<Object>();
		li.add("Saurabh");
		li.add(23);
		li.add(45.5f);
		li.add('A');
		li.add(898789977797L);
		
	System.out.println("Element at second index is  "+li.get(2));	;
		
		
		List<Object> li2=new ArrayList<Object>();
		li2.add("Gaurabh");
		li2.add(93);
		li2.add(75.5f);
		li2.add('C');
		li2.add(89779977797L);
		
		li.addAll(li2);
		
		for(Object x:li)
		{
			System.out.println(x);
		}
		
	boolean flag=	li.contains('C');
	
	System.out.println("Does the list contains C " +flag);
		
		
//		li.clear();
//		
//		System.out.println(li);
//		
		
		
		
		

	}

}
