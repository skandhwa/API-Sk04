package Collections;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ListExample1 {

	public static void main(String[] args) {
		
		List<Integer> li=new ArrayList<Integer>();
		li.add(12);
		li.add(45);
		li.add(99);
		li.add(102);
		
		//System.out.println(li);
		
		for(Integer x:li)
		{
			System.out.println(x);
		}
		
		Iterator itr=li.iterator();
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
		
		
		
		

	}

}
