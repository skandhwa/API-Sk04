package Collections;

import java.util.ArrayList;
import java.util.List;

public class ListExample4 {

	public static void main(String[] args) {
		

		List<Integer> li=new ArrayList<Integer>();
		li.add(12);
		li.add(45);
		li.add(99);
		
		//li.clear();
		
	boolean flag=	li.isEmpty();
	
	System.out.println("Is the list empty" +flag);
	
	
		

	}

}
