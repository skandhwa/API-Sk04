package Collections;

import java.util.Arrays;
import java.util.List;

public class ArraytoArrayLIst {

	public static void main(String[] args) {
		
		String []lang= {"Java" ,"Python","C","C++"};
		
	List li=	Arrays.asList(lang);
	
	for(Object x:li)
	{
		System.out.println(x);
	}
		

	}

}
