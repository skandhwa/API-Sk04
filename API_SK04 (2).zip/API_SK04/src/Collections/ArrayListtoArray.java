package Collections;

import java.util.ArrayList;
import java.util.List;

public class ArrayListtoArray {

	public static void main(String[] args) {
		
		List<Integer> li=new ArrayList<Integer>();
		li.add(23);
		li.add(45);
		li.add(99);
		
	Object[] obj=	li.toArray();
	
	for(Object x:obj)
	{
		System.out.println(x);
	}
	
	
		

	}

}
