package Collections;

import java.util.ArrayList;

public class ListExample5 {

	public static void main(String[] args) {
		
		ArrayList<String> li=new ArrayList<String>();
		
		li.add("Java");
		li.add("C");
		li.add("C++");
		li.add("Python");
		
ArrayList<String> li2=new ArrayList<String>();
		
		li2.add("English");
		li2.add("Japanese");
		li2.add("C++");
		li2.add("Python");
		
		
		li.retainAll(li2);
		
		System.out.println(li);
		
		

	}

}
