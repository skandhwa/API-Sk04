package StringinJava;

public class StringSwapCode {

	public static void main(String[] args) {
		
		
		String str1="ABC";
		String str2="DEF";
		
		int y=str2.length();///y=3
		
		str1=str1+str2;/// str1=ABCDEF
		int x=str1.length();///x=6
		
		str2=str1.substring(0,x-y);///str2=ABCDEF.substring(0,3);
		
		str1=str1.substring(y);///ABCDEF.substring(3)
		
		
		System.out.println("After swapping values are "+str1 +" "+str2);
		
		
		
		String str3="Saurabh";
		
	String str4=	str3.substring(3, 4);
	
	System.out.println(str4);
		
		
	}

}
