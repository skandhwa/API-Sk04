package StringinJava;

public class StringExamples7 {

	public static void main(String[] args) {
		
		String str="INDIA";
	String str1=	str.toUpperCase();
		System.out.println(str1);
		
		
		
		String str2="Ind   ia  is a repub  lic   country";
	String str3=	str2.trim();
	System.out.println(str3);
		
		

	}

}
