package StringinJava;

public class StringEx1 {

	public static void main(String[] args) {
		
		String str="India";
		
		String s=new String("India");
		
		String str1="India";
String str2=str1.concat("Republic");
		System.out.println(str2);
		
		
		
		
	}

}
