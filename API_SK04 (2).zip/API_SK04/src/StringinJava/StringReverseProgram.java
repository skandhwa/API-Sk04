package StringinJava;

public class StringReverseProgram {

	public static void main(String[] args) {
		
		String str="Saurabh";
		
		String str1=str;
		String revstr="";
		
		for(int i=str.length()-1;i>=0;i--)///i=5,5>=0//i=4,4>=0
		{
			revstr=revstr+str.charAt(i);///revstr=h+b=hb//hb+a=hba
		}
		
		System.out.println("The reverse of the string is "+revstr);
		
		if(str1.equals(revstr))
		{
			System.out.println();
		}
		

	}

}
