package StringinJava;

public class StringExamples8 {

	public static void main(String[] args) {

           String str="India is a republic and India is a democratic country";
           
       int x=    str.indexOf("is",15);
       
       System.out.println("index of is is "+x);
		

	}

}
