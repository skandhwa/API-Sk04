package StringinJava;

public class StringExamples2 {

	public static void main(String[] args) {
		
		String str1="Indian Team";
	char ch=	str1.charAt(8);
	System.out.println(ch);
	
	int x=str1.length();
	System.out.println("The length of string is "+x);
	
	
	String str3="  Republic";
String str4=	str3.substring(4); 
System.out.println(str4);


String str5="Republic";
String str6=str5.substring(2, 3);
System.out.println(str6);

		
		

	}

}
