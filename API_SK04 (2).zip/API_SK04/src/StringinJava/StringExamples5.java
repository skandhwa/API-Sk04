package StringinJava;

public class StringExamples5 {

	public static void main(String[] args) {
		
		String str="Welcome home sweet home";
	String str1=	str.replaceAll("home", "abroad");
	
	System.out.println(str1);
	
	
	String str2="Sam";
	String str3=str2.replace('S', 'R');
	System.out.println("The new value is "+str3);
	
	

	}

}
