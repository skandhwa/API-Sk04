package StringinJava;

public class StringSplitMethodExamples {

	public static void main(String[] args) {
		
		String str="India is a  vast  country";
	String []words=	str.split("vast");
	
	System.out.println(words[0]);
	
	System.out.println(words[1]);
	
	
		

	}

}
