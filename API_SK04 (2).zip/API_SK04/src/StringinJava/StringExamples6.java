package StringinJava;

public class StringExamples6 {

	public static void main(String[] args) {
		
		String str="Java";
		String str1="java";
		
	boolean flag=	str.equalsIgnoreCase(str1);
	System.out.println("The two strings are equal or not ?? "+flag);
		
		
		

	}

}
