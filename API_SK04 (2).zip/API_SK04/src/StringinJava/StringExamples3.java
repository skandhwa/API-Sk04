package StringinJava;

public class StringExamples3 {

	public static void main(String[] args) {
	
		String str="India is a republic country";
	boolean flag=	str.contains(null);
	System.out.println(flag);
		

	}

}
