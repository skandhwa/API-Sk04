package StringinJava;

public class StringExamples4 {

	public static void main(String[] args) {
		
		String str="India";
		boolean flag=str.isEmpty();
		System.out.println(flag);
		

	}

}
