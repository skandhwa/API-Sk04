package StringinJava;

public class StringExamples9 {

	public static void main(String[] args) {
		
		float x=10.0f;
		String str=String.valueOf(x);
		System.out.println(str);
		
		char ch='D';
		String str1=String.valueOf(ch);
		System.out.println(str1);
		
		

	}

}
