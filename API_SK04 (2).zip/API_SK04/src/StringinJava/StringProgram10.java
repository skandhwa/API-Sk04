package StringinJava;

public class StringProgram10 {

	public static void main(String[] args) {
		
		String str="India    is    a   republic  country";
		
	String str1=	str.replace("  ", " ");
	System.out.println("The new string is "+str1);
		
		
		

	}

}
