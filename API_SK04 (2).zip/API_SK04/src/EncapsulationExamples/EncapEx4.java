package EncapsulationExamples;

public class EncapEx4 {

	private String name="Saurabh";

	public String getName() {
		return name;
	}

	
	
	
	
}



