package EncapsulationExamples;

 class Encap4
{
	private String name;
	private int id;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	
	
}
public class EncapsulationEx3 {

	public static void main(String[] args) {
		 
		Encap4 obj=new Encap4();
		obj.setId(45);
		obj.setName("Saurabh");
		
	System.out.println(obj.getId());	;
		obj.getName();

	}

}
