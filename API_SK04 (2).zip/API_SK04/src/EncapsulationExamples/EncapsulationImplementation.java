package EncapsulationExamples;

public class EncapsulationImplementation {

	public static void main(String[] args) {
		
		EncapsulationEx1 obj=new EncapsulationEx1();
		obj.setName("Ramesh");
		obj.setId(778);
		
		
		System.out.println(obj.getName());
		System.out.println(obj.getId());
		
		
		EncapEx4 obj2=new EncapEx4();
		obj2.getName();
		
		

	}

}
