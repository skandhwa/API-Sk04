package FinalKeywordExample;

//final class F12
//{
//	void display()
//	{
//		System.out.println("hello");
//	}
//}
//
//class F13 extends F12
//{
//	void test()
//	{
//		System.out.println("hi");
//	}
//}
//
//
//public class FinalClassEx {
//
//	public static void main(String[] args) {
//		
//		F13 obj=new F13();
//		obj.display();
//		obj.test();
		

//	}
//
//}
