//package FinalKeywordExample;
//
//class F10
//{
//	final int sum(int x,int y)
//	{
//		return x+y;
//	}
//}
//
//class F11 extends F10
//{
//	
//	int sum(int x,int y)
//	{
//		return x+y;
//	}
//	
//}
//
//public class FinalForMethods {
//
//	public static void main(String[] args) {
//		
//		F11 obj=new F11();
//	System.out.println(obj.sum(10,20));	
//		
//
//	}
//
//}
