package FinalKeywordExample;


class H1
{
	final static int x=20;
	static void display()
	{
		//x=40;
		System.out.println(x);
	}
}

public class FinalForVariable {

	public static void main(String[] args) {
		
		H1.display();
		

	}

}
