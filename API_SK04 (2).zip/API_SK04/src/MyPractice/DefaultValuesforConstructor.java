package MyPractice;

class A1
{
	
	A1()
	{
		System.out.println("Hello");
	}
	int id;
	String name;
	
	void display()
	{
		System.out.println(id+" "+name);
	}
	
}

public class DefaultValuesforConstructor {

	public static void main(String[] args) {
		
		A1 obj=new A1();
		obj.display();
		
		
		

	}

}
