package MyPractice;

class A3
{
	void add(int a,int b)
	{
		int c=a+b;
		System.out.println(c);
	}
}

public class MethodRturnTypeEx {

	public static void main(String[] args) {
		
		A3 obj=new A3();
		obj.add(23, 99);

	}

}
