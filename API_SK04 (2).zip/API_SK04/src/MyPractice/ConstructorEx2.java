package MyPractice;

class B
{
	B()
	{
		
	}
	
	void display()
	{
		System.out.println("Hello");
	}
}


public class ConstructorEx2 {

	public static void main(String[] args) {
		
		B obj=new B();
		
		

	}

}
