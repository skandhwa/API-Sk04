package MyPractice;

public class StaticMethodChangeex {
	
	int id;
	String ename;
	static String comname="CTS";
	
	StaticMethodChangeex(int i,String n)
	{
		id=i;
		ename=n;
	}
	
	void display()
	{
		System.out.println(id+"  "+ename+" "+comname);
	}
	
	static void change()
	{
		comname="Wipro";
	}
	

	public static void main(String[] args) {
		

	}

}
