package MyPractice;

class Test1
{
   int id;
   String name;
   float salary;
   Test1(int id,String name,float salary)
   {
	 this.id=id;
	  this.name=name;
	  this.salary=salary;
   }
   
   void display()
   {
	   System.out.println(id+"  "+name+" "+salary);
   }
   
   
}

public class ThisKeyWordEx {

	public static void main(String[] args) {
		
		Test1 obj=new Test1(1234,"Saurabh",78000f);
		obj.display();
		
		

	}

}
