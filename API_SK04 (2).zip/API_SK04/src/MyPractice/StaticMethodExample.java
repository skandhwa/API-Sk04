package MyPractice;

class A5
{
	 static void display()
	{
		System.out.println("hello");
	}
	 
	 static void add(int a,int b)
	 {
		 int c=a+b;
		 System.out.println(c);
	 }
	 
	 static int sub(int a,int b)
	 {
		 return a-b;
	 }
	 
}

public class StaticMethodExample {

	public static void main(String[] args) {
		
		A5.display();
		A5.add(34, 67);
	System.out.println(A5.sub(67, 12));	
		
		
		
//		A5 obj=new A5();
//		obj.display();
//		

	}

}
