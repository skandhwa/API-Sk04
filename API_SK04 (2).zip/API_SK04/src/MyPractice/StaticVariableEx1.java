package MyPractice;

class A4
{
	int id;
	String ename;
	static String comname="CTS";
	
	A4(int i,String n)
	{
		id=i;
		ename=n;
	}
	
	void display()
	{
		System.out.println(id+"  "+ename+" "+comname);
	}
	}
public class StaticVariableEx1 {

	public static void main(String[] args) {
		
		A4 obj=new A4(1234,"Saurabh");
		obj.display();
		
		A4 obj1=new A4(4567,"Harish");
		obj1.display();
		
		
		
		

	}

}
