package MyPractice;

public class VariablesinJava {
	
	int x=20;
	
	
	void add()
	{
		int a=10;
		int b=20;
		int c=a+b+x;
		System.out.println(c);
	}
	
	void sub()
	{
		int y=x+40;
		System.out.println(y);
	}
	
	

	public static void main(String[] args) {
		
		VariablesinJava obj=new VariablesinJava();
		obj.add();
		obj.sub();
		

	}

}
