package MyPractice;

class A7
{
	private static String str="Hello";


static class StaticNestedClass
{
	public void display()
	{
		System.out.println(str);
		System.out.println("Welcome");
	}
}

}
public class StaticClassExample {

	public static void main(String[] args) {
		
		
		A7.StaticNestedClass obj=new A7.StaticNestedClass();
				obj.display();

	}

}
