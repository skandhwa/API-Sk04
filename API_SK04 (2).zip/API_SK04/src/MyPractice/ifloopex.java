package MyPractice;

public class ifloopex {

	public static void main(String[] args) {
		
		int x=10;
		
		if(x<=15)
		{
			if(x<=18)
			{
				if(x<=19)
				{
					System.out.println("true");
				}
			}
		}
		

	}

}
