package MyPractice;

class A6
{
	static int cube(int x)
	{
		return x*x*x;
	}
}

public class StaticMethodEx2 {

	public static void main(String[] args) {
		
	System.out.println(A6.cube(12));	;
		

	}

}
