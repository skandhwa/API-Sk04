package MyPractice;

class Student
{
	int roll;
	String name,course;
	float fees;


Student(int roll,String name,String course)
{
	this.roll=roll;
	this.name=name;
	this.course=course;
}

Student(int roll,String name,String course,float fees)
{
//	this.roll=roll;
//	this.name=name;
//	this.course=course;
	this(roll,name,course);
	this.fees=fees;
	
}

void display()
{
	System.out.println(roll+"  "+name+"  "+course+"  "+fees);
}

}

public class ReusingConstructorThis {

	public static void main(String[] args) {
		
		Student obj=new Student(1234,"Harsh","Java");
		obj.display();
		
		Student obj1=new Student(2234,"Tom","Testing",56000f);
		obj1.display();
		
		

	}

}
