package MyPractice;

public class ArithmeticOperators {

	public static void main(String[] args) {
		
		
		int z=4/10;
	    System.out.println(z);
	    
	    int p=75;
	    int q=p%8;
	    
	    System.out.println(q);

	}

}
