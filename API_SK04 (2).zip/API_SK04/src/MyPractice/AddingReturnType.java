package MyPractice;

class C3
{
	int add(int a,int b)
	{
		return a+b;
	}
}


public class AddingReturnType {

	public static void main(String[] args) {
		
		C3 obj=new C3();
	System.out.println(obj.add(20, 30));	
		

	}

}
