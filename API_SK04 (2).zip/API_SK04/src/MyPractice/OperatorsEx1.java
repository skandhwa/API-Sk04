package MyPractice;

public class OperatorsEx1 {

	public static void main(String[] args) {
		
		
//		int a=20;
//		int b=10;
//		
//		int c= b++ + --a + ++a + --b;
//		
//		// 10 + 19 + 20 +  10     
//		
//		System.out.println(c);///b=11,a=19
		
		
		int x=10;
		int y=15;
		int z=20;
		
		int r= ++x + z++ - --y + x++ + y++ + ++z;
		
		System.out.println(r);
		
		
		/// 11 + 20 - 14 + 11 + 14 + 22
		
		
		//x=12,z=21, y=15
		
		
		
		
		
				
				
		
		
	
		
		
		
		

	}

}
