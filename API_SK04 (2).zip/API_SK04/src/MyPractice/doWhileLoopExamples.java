package MyPractice;

public class doWhileLoopExamples {

	public static void main(String[] args) {
		
		int i=5;
		do
		{
			System.out.println(i);//5//6//7//8//9
			i++;//5++//6++//7++//8++
		}
		while(i<10);//6<10//7<10//8<10//9<10
		
		

	}

}
