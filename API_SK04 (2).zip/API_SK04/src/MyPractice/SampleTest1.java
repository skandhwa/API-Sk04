package MyPractice;

public class SampleTest1 {
	
    public static void main(String[] args) {
        int num1 = 10;
        int num2 = 20;
        
        if (num1 <= num2) {
            System.out.println("The largest number is: " + num1);
        } else {
            System.out.println("The largest number is: " + num1); 
        }
    }
}

	
	


