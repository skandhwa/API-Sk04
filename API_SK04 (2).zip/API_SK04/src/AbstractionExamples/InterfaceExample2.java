package AbstractionExamples;

interface P
{
	 void display();
	 //void test1();
	 //void test2();
}

interface Q extends P
{
	void test();
}

class A8 implements P,Q
{
	public void display()
	{
		System.out.println("hello");
	}
	
	public void test()
	{
		System.out.println("Hi");
	}
}

public class InterfaceExample2 {

	public static void main(String[] args) {
		
//		A8 obj=new A8();
//		obj.display();
//		obj.test();
		
		
		Q ref=new A8();
		ref.display();
		ref.test();
		
		
		

	}

}
