package AbstractionExamples;

public interface Test5 {
	
	void test();
	void display();
	
	

}



