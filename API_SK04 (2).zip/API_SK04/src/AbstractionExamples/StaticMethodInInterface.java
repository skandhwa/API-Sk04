package AbstractionExamples;

interface Draw
{
	void test();
	
	static int square(int x)
	{
		return x*x*x;
	}
}

class Test2 implements Draw
{
	public void test()
	{
		System.out.println("Hi");
	}
}


public class StaticMethodInInterface {

	public static void main(String[] args) {
		
	System.out.println(Draw.square(4));	
		
		
		
	}

}
