package AbstractionExamples;

public class MyImplementation implements Test5 {
	
	public void test()
	{
		System.out.println("Hello");
	}
	
	public void display()
	{
		System.out.println("Hi");
	}
	
	

	public static void main(String[] args) {
		
		
		Test5 ref=new MyImplementation();
		ref.test();
		ref.display();
		

	}

}
