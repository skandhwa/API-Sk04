package AbstractionExamples;

interface K
{
	void display();
	void print();
}

class K1 implements K
{
	public void display()
	{
		System.out.println("hello");
	}
	public void print()
	{
		System.out.println("Hi");
	}
	
}

class K2 implements K
{
	public void display()
	{
		System.out.println("hello i am of k2");
	}
	public void print()
	{
		System.out.println("Hi I am of K2");
	}
}



public class InterfaceEx1 {

	public static void main(String[] args) {
		
		K ref=new K1();
		ref.display();
		ref.print();
		

	}

}
