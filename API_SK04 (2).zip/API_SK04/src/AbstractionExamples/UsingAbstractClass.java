package AbstractionExamples;

abstract class demo
{
	void display()
	{
		System.out.println("hello");
	}
	
//	static void test()
//	{
//		System.out.println("Hi");
//	}
	
	abstract void message();
	
}

class Demo2 extends demo
{
	void message() 
	{
		
		System.out.println("How r u");
	}
	
}



public class UsingAbstractClass {

	public static void main(String[] args) {
		
		demo ref=new Demo2();
		ref.message();
		ref.display();
		//demo.test();
		
		

	}

}
