package AbstractionExamples;

abstract class Shape
{
	abstract void draw();
}

class Rectangle extends Shape
{
	void draw()
	{
		System.out.println("drawing rectangle");
	}
}
class Circle extends Shape
{
	void draw()
	{
		System.out.println("drawing circle");
	}
}

public class AbstractClassEx2 {

	public static void main(String[] args) {
		
		Shape ref=new Rectangle();
		ref.draw();
		Shape ref1=new Circle();
		ref1.draw();
		
		

	}

}
