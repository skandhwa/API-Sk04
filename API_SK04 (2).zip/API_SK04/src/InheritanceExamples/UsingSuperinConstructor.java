package InheritanceExamples;

class F1
{
	F1()
	{
		System.out.println("Hello");
	}
}

class F2 extends F1
{
	F2()
	{
		super();
		System.out.println("Hi");
		
	}
	
}
public class UsingSuperinConstructor {

	public static void main(String[] args) {
		
		F2 obj=new F2();
		
		
		

	}

}
