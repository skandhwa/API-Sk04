package InheritanceExamples;

class Test6
{
	void message()
	{
		System.out.println("How r u");
	}
}


class Test7 extends Test6
{
	void message()
	{
		System.out.println("hello");
	}
}

class Test8 extends Test7
{
	void message()
	{
		System.out.println("Hi");
	}
	
	void message2()
	{
		System.out.println("Welcome");
	}
	
	void test()
	{
		message();
		message2();
		super.message();
	}
}


public class superforMethod {

	public static void main(String[] args) {
		
		Test8 obj=new Test8();
		obj.test();
		

	}

}
