package InheritanceExamples;

class E1
{
	String colour= "red";
	
}

class E2 extends E1
{
	String colour="blue";
	void display()
	{
		System.out.println("The colour is "+colour);
		System.out.println("The colour of parent class "+super.colour);
	}
}



public class UsingSuperKeyword {

	public static void main(String[] args) {
		
		E2 obj=new E2();
		obj.display();
		
		
		

	}

}
