package InheritanceExamples;

class D1
{
	void display()
	{
		System.out.println("hello");
	}
}

class D2 extends D1
{
	void test()
	{
		System.out.println("hi");
	}
}

class D3 extends D2
{
	void  message()
	{
		System.out.println("Welcomes");
	}
}



public class UsingMultileveInheritance {

	public static void main(String[] args) {
		
		D3 obj=new D3();
		obj.test();
		obj.display();
		obj.message();
		
		
		

	}

}
