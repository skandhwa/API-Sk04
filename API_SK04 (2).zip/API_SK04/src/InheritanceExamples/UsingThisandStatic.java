package InheritanceExamples;

class Test5
{
	static int x=10;
	Test5(int x)
	{
		this.x=x;
	}
	
	static void display()
	{
		System.out.println("The value is "+x);
	}
	
}



public class UsingThisandStatic {

	public static void main(String[] args) {
		
//		Test5 obj=new Test5(10);
//		obj.display();
		
		Test5.display();
		

	}

}
