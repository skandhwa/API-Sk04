package InheritanceExamples;

class Test3
{
	int add(int a,int b)
	{
		return a+b;
	}
}

class Test4 extends Test3
{
	int sub(int a,int b)
	{
		return a-b;
	}
}


public class UsingSingleInheritannce {

	public static void main(String[] args) {
		
		Test4 obj=new Test4();
	System.out.println(obj.add(34, 55));	
	System.out.println(	obj.sub(66, 12));
		
		

	}

}
