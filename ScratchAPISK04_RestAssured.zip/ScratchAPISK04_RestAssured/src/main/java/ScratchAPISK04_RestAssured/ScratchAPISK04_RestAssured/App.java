package ScratchAPISK04_RestAssured.ScratchAPISK04_RestAssured;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
    }
}
