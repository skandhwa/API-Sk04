package Practice_APISK04.Practice_APISK04;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;

import static io.restassured.RestAssured.*;

public class APIKeyAuthentication {

	public static void main(String[] args) {
		
		RestAssured.baseURI="https://api.openweathermap.org";
		
	String Response=	given().log().all()
		.queryParam("q", "Kolkata")
		.queryParam("appid", "4c834f2c753226cb4953a66effe44611")
		.when().get("data/2.5/weather")
		.then().assertThat().statusCode(200).
		extract().response().asString();
	
	System.out.println(Response);
	
	JsonPath js=new JsonPath(Response);
int Id=	js.getInt("id");

System.out.println("The ID value is "+Id);
	
		
		

	}

}
