package Practice_APISK04.Practice_APISK04;
import io.restassured.RestAssured;
import static io.restassured.RestAssured.*;

import java.util.LinkedHashMap;
import java.util.Map;

public class BearerTokenAuthentication {

	public static void main(String[] args) {
		
		String token="Bearer 763104180b5819c234fcc27935a66b106d87efb0aa1c80a470ee4b536f703079";
		RestAssured.baseURI="https://gorest.co.in";
		Map<String,Object> mp=new LinkedHashMap<String,Object>();
		mp.put("name", "Harshit");
		mp.put("gender", "male");
		mp.put("email", "testxyz123@gmail.com");
		mp.put("status", "active");
		
		
		
		
String Response=		given().log().all().headers("Authorization",token)
		.headers("Content-Type","application/json")
		.body(mp)
		.when().post("public/v2/users")
		.then().assertThat().statusCode(201)
		.extract().response().asString();

System.out.println(Response);
		
		
		
		

	}

}
