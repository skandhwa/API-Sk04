package Practice_APISK04.Practice_APISK04;

import java.io.File;

import com.beust.ah.A;

import io.restassured.RestAssured;
import static io.restassured.RestAssured.*;


public class UsingMultiPartMethod {

	public static void main(String[] args) {
		
		File f=new File("D:\\Java Program Assignment.txt");
		File f1=new File("C:\\Users\\saura\\OneDrive\\Pictures\\Test123.png");
		
		RestAssured.baseURI="https://httpbin.org";
		
		String Response=		given().relaxedHTTPSValidation().
				log().all().headers("Content-Type","multipart/form-data")
				
				.multiPart("file",f)
				.multiPart("file2",f1)
				.when().post("post").then().log().all().extract()
				.response().asString();
		
		System.out.println(Response);
		
		
		

	}

}
