package Utilities;

public class BaseClass {

}
