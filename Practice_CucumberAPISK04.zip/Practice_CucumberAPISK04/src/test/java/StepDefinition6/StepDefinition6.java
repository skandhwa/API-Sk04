package StepDefinition6;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;



import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class StepDefinition6 {
	
	@Before
	public void test()
	{
		System.out.println("Connected to Database");
	}
	
	
	
	
	
	@After
	public void test1()
	{
		System.out.println("DB disconnected");
	}
	
	
	@Before("@test1")
	public void beforeTest1()
	{
		System.out.println("Before test1 method");
	}
	
	@After("@test1")
	public void afterTest1()
	{
		System.out.println("After test1 method");
	}
	
	@Before("@test2")
	public void beforeTest2()
	{
		System.out.println("Before test2 method");
	}
	
	@After("@test2")
	public void afterTest2()
	{
		System.out.println("After test2 method");
	}
	
	
	
	@Given("User Opens the web application application in the browser")
	public void user_opens_the_web_application_application_in_the_browser() {
	    
		System.out.println("Application opened");
		
		
	}

	@Given("User will enter the {string}")
	public void user_will_enter_the(String string) {
		
		System.out.println("Hello");
	    
	}

	@When("User will click on the login button")
	public void user_will_click_on_the_login_button() {
		
		System.out.println("Hii");
	    
	}

	@Then("User will be able to login in the home page of the application")
	public void user_will_be_able_to_login_in_the_home_page_of_the_application() {
	   
		
		System.out.println("Welcome");
	}

	@Then("User will be getting the appropriate error message")
	public void user_will_be_getting_the_appropriate_error_message() {
	    
		
		System.out.println("Error");
	}
	
	@Given("User will enter the username")
	public void user_will_enter_the_username() {
	   
		
		System.out.println("New");
	}

	@Given("User will enter the password")
	public void user_will_enter_the_password() {
		
		System.out.println("test");
	    
	}
	
	
	@Then("User will be navigated to home page")
	public void user_will_be_navigated_to_home_page() {
	    
	}

	@Then("the user will then go to Add to cart section")
	public void the_user_will_then_go_to_add_to_cart_section() {
	    
	}

	@Then("the user will then go to my favourites section")
	public void the_user_will_then_go_to_my_favourites_section() {
	    
	}

	@Then("the user will then go to change user setting section")
	public void the_user_will_then_go_to_change_user_setting_section() {
	   
	}

	

@Given("User is on HRMlogin Page")
public void user_is_on_hr_mlogin_page() {
   
}

@When("User will enter the credentials")
public void user_will_enter_the_credentials(io.cucumber.datatable.DataTable dataTable) {
    
	WebDriver driver=new ChromeDriver();
	driver.get("https://www.tutorialspoint.com/selenium/practice/selenium_automation_practice.php");
	driver.manage().window().maximize();
	 List<List<String>> signUpForm = dataTable.asLists(String.class);
         
	String Username=signUpForm.get(0).get(0);
	String Email=signUpForm.get(0).get(1);
	String Mobile=signUpForm.get(0).get(2);
	String DOB=signUpForm.get(0).get(3);
	
	
	driver.findElement(By.name("name")).sendKeys(Username);
	
	driver.findElement(By.name("email")).sendKeys(Email);
	
	driver.findElement(By.name("mobile")).sendKeys(Mobile);
	
	driver.findElement(By.name("dob")).sendKeys(DOB);
       
        
        
        
        
        
        
        
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}

@Then("User will be submmiting the form")
public void user_will_be_submmiting_the_form() {
    
}
	
	
	
	
	
	
	
	
	
	

}
