package SerDer4;

import java.util.List;

import SerializationDeserialization2.EmployeeAddress;

public class Employee4POJO {
	
	private String name;
	private String job;
	private double salary;
	private int pincode;
	private List<String> bank;
	private EmployeeAddress4POJO empaddress;
	
	
	
	public EmployeeAddress4POJO getEmpaddress() {
		return empaddress;
	}

	public void setEmpaddress(EmployeeAddress4POJO empaddress) {
		this.empaddress = empaddress;
	}

	public List<String> getBank() {
		return bank;
	}

	public void setBank(List<String> bank) {
		this.bank = bank;
	}

	private EmployeeAddress empAddress;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getJob() {
		return job;
	}

	public void setJob(String job) {
		this.job = job;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public int getPincode() {
		return pincode;
	}

	public void setPincode(int pincode) {
		this.pincode = pincode;
	}

	public EmployeeAddress getEmpAddress() {
		return empAddress;
	}

	public void setEmpAddress(EmployeeAddress empAddress) {
		this.empAddress = empAddress;
	}
	
	
	

}
