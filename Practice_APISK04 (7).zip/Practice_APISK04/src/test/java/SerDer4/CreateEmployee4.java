package SerDer4;

import java.util.ArrayList;
import java.util.List;

import org.testng.annotations.Test;

import SerializationDeserialization2.EmployeeAddress;
import SerializationDeserialization2.EmployeePOJO2;
public class CreateEmployee4 {
	
	@Test
	public  void CreateEmployee()
	{
	EmployeeAddress4POJO empaddress=new EmployeeAddress4POJO();
	empaddress.setCity("Delhi");
	empaddress.setHousenum(34);
	empaddress.setStreet("PR lane");
	
	List<String> banks=new ArrayList<String>();
	banks.add("SBI");
	banks.add("ICICI");
	banks.add("HDFC");
	
	Employee4POJO emp2=new Employee4POJO();
	emp2.setName("Robin");
	emp2.setJob("Manager");
	emp2.setPincode(713304);
	emp2.setSalary(90000.67);
	emp2.setEmpAddress(null);
	emp2.setBank(banks);
	
	
	
	
	
	
	
	
	
	}
	
	
	
	
	
	
	
	

}
