package DBIntegrationRestAssured;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;



public class DBConnection1 {
	
	
	public static Object test(int x) throws SQLException
	{
		Connection mycon=null;
		Statement myst=null;
		ResultSet myRs=null;
		Object obj=null;
		
		mycon=DriverManager.getConnection("jdbc:mysql://localhost:3306/student2","root","root");
		
		System.out.println("connection successfull");
		
		myst=	mycon.createStatement();
		
		//myRs=	myst.executeQuery(SQLQueries.SQLQuery());
		
		
		
		
		while(myRs.next())
		{
		obj=	myRs.getString(x);
		
		
		}
		return obj;
		
		
	}
	

}
