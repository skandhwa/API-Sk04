package DBIntegrationRestAssured;

import static io.restassured.RestAssured.given;

import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.Map;

import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;

public class CreateUserFromDB {

	public static void main(String[] args) throws SQLException {
		
		Map<String,Object> mp=new LinkedHashMap<String,Object>();
		mp.put("StudentID",DBConnection1.test(1));
		mp.put("lastname",DBConnection1.test(2));
		mp.put("Firstname",DBConnection1.test(3));
		mp.put("Address",DBConnection1.test(4));
		mp.put("City",DBConnection1.test(5));
		
		RequestSpecification req=new RequestSpecBuilder()
				.setBaseUri("http://httpbin.org")
				.setContentType(ContentType.JSON).build();
		
		RequestSpecification respec=given().log().all().spec(req).body(mp);
		
		ResponseSpecification res=new ResponseSpecBuilder().
				expectStatusCode(200).
				expectContentType(ContentType.JSON).build();
		
		
		String Response= respec.when().post("post").then().log().all().spec(res)

				.extract().response().asString();
		
		System.out.println(Response);
		

	}

}
