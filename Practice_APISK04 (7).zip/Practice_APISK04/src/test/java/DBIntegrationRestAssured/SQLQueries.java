package DBIntegrationRestAssured;

public class SQLQueries {
	
	public static String SQLQuery()
	{
		String str="select * from student2.persons where city='Hyderabad'";
		return str;
		
		
	}
	

}
