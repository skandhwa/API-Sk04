package Practice_APISK04.Practice_APISK04;

import org.testng.Assert;

import TestData.TestDataPayload;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;

public class MockJsonTestCase {

	public static void main(String[] args) {
		
		///Print No of courses returned by API

		int sum=0;
		JsonPath js=new JsonPath(TestDataPayload.courseDetails());
       int size= js.getInt("courses.size()");
       System.out.println("Total number of courses are "+size);
       
       //Print Purchase Amount

       int purchase_amount=js.getInt("dashboard.purchaseAmount");
       System.out.println("Total purchase amount is "+purchase_amount);
       
       //Print Title of the first course
       
       String course_title=js.getString("courses[0].title");
       System.out.println("The course title is "+course_title);
       
       
       ///Print All course titles and their respective Prices

       System.out.println("Course title and their respective price are ");
       
       for(int i=0;i<size;i++)//i=0,0<3//i=1,1<3//i=2,2<3//i=3,3<3
       {
    	String Course_title=   js.getString("courses["+i+"].title");
    	int Course_price=   js.getInt("courses["+i+"].price");
    	System.out.println(Course_title+" "+Course_price);
    	
    	
    	   
       }
       
       // Print no of copies sold by RPA Course

       
       int rpa_course=js.getInt("courses[2].copies");
       System.out.println("The number of copies sold by RPA is  "+rpa_course);
       
       
       //Verify if Sum of all Course prices matches with Purchase Amount

       for(int i=0;i<size;i++)//i=0,0<3//i=1,1<3//i=2,2<3//i=3,3<3
       {
    	int Course_copies=   js.getInt("courses["+i+"].copies");
    	int Course_price=   js.getInt("courses["+i+"].price");
    	int amount=Course_copies*Course_price;//300//160//450
    	sum=sum+amount;//sum=0+300=300//sum=300+160=460//sum=460+450=910
    	
    	
    	
    	
    	   
       }
       
       Assert.assertEquals(purchase_amount,sum);
   	System.out.println("Test case passed");
       
       

       
	}

}
