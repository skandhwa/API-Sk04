package Practice_APISK04.Practice_APISK04;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import TestData.TestDataPayload;

import static io.restassured.RestAssured.*;
import io.restassured.RestAssured;

public class UsingDataProviderEx2 {
	
	@DataProvider(name="BooksData")
	public Object [][] getData()
	{
		return new Object [][]
				{
			{"bgdrty","78654"},
			{"jkyset","98654"},
			{"nhgfdr","65439"}
				};
	}
	
	@Test(dataProvider="BooksData")
	public void testaddboook(String isbn,String aisle)
	{
		RestAssured.baseURI="http://216.10.245.166";
		
		String Response=	given().log().all().headers("Content-Type","application/json")
		.body(TestDataPayload.addBook(isbn,aisle))
		.when().post("Library/Addbook.php")
		.then().log().all().
		assertThat().statusCode(200)
		.extract().response().asString();
		
		
		System.out.println(Response);
		
	}
	
	
	
	
	

}
