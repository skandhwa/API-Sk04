package Practice_APISK04.Practice_APISK04;

import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import TestData.TestDataPayload;

import static io.restassured.RestAssured.*;
import io.restassured.RestAssured;
import io.restassured.filter.session.SessionFilter;

public class SessionFilterExample {
	
	
	@BeforeSuite
	public static SessionFilter prereq()
	{
		SessionFilter sess=new SessionFilter();
		return sess;
	}
	
	@Test
	public void alogin()
	{
		
		RestAssured.baseURI="https://httpbin.org";
		
String Response=		given().log().all().filter(SessionFilterExample.prereq()).
		body(TestDataPayload.addName("Saurabh","QA lead")
				).when().post("post")
		.then().log().all().extract().response().asString();


System.out.println(Response);
		
		
	}
	
	@Test
	public void addUser()
	{
		
	}
	
	
	

}
