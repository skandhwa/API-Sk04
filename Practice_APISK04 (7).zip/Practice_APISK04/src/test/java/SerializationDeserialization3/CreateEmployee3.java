package SerializationDeserialization3;

import static io.restassured.RestAssured.given;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import SerializationEx1.EmployeePOJO;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;

public class CreateEmployee3 {

	public static void main(String[] args) throws JsonProcessingException {
		
		EmployeePOJO3 emp1=new EmployeePOJO3();
		emp1.setJob("QA lead");
		emp1.setLocation("Kolkata");
		emp1.setName("Ron");
		emp1.setSalary(90000.0f);
		
		EmployeePOJO3 emp2=new EmployeePOJO3();
		emp2.setJob("Manager");
		emp2.setLocation("Delhi");
		emp2.setName("Tom");
		emp2.setSalary(80000.0f);
		
		EmployeePOJO3 emp3=new EmployeePOJO3();
		emp3.setJob("Analyst");
		emp3.setLocation("Kolkata");
		emp3.setName("Harry");
		emp3.setSalary(70000.0f);
		
		List<EmployeePOJO3> li=new ArrayList<EmployeePOJO3>();
		li.add(emp1);
		li.add(emp2);
		li.add(emp3);
		
		ObjectMapper obj=new ObjectMapper();
		
		String empJSON=	obj.writerWithDefaultPrettyPrinter().writeValueAsString(li);
			
		
		RequestSpecification req=new RequestSpecBuilder()
				.setBaseUri("http://httpbin.org")
				.setContentType(ContentType.JSON).build();
		
		RequestSpecification respec=given().log().all().spec(req).body(empJSON);
		
		ResponseSpecification res=new ResponseSpecBuilder().
				expectStatusCode(200).
				expectContentType(ContentType.JSON).build();
		
		
		String Response= respec.when().post("post").then().log().all().spec(res)

				.extract().response().asString();
		
		System.out.println(Response);
		
		
		////Deserailization
		
		
		EmployeePOJO empObj=obj.readValue(empJSON, EmployeePOJO.class);
		System.out.println();
		System.out.println("Doing Serilization");
		
		System.out.println(empObj.getName());
		System.out.println(empObj.getSalary());
		
		
		
		

	}

}
