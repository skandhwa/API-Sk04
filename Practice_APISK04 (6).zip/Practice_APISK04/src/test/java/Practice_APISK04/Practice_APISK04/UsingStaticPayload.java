package Practice_APISK04.Practice_APISK04;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;

import static io.restassured.RestAssured.*;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

import org.testng.Assert;

public class UsingStaticPayload {

	public static void main(String[] args) throws IOException {
		
		RestAssured.baseURI="https://reqres.in";
		String Expected_createddate="2024-10-02";
		
	String Response=	given().log().all().headers("content-type","application/json")
		.body( new String(Files.readAllBytes(Paths.get("E:\\APISK03_TestData24thJuly.txt"))))
		.when().post("api/users")
		.then().log().all().extract().response().asString();
	
	System.out.println(Response);
	
	JsonPath js=new JsonPath(Response);
	String Created_date=	js.getString("createdAt");
	System.out.println(Created_date);
	
	String []a=Created_date.split("T");
	System.out.println("First Index of array is  "+a[0]);
	
	Assert.assertEquals(Expected_createddate, a[0]);
	
	System.out.println("Test case passed");
	
	
	
		
		
		

	}

}
