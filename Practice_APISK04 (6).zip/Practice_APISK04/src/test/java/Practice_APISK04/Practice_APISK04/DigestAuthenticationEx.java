package Practice_APISK04.Practice_APISK04;

import io.restassured.RestAssured;
import static io.restassured.RestAssured.*;

public class DigestAuthenticationEx {

	public static void main(String[] args) {
		
		RestAssured.baseURI="https://httpbin.org/digest-auth";
		
	String Response=	given().log().all().auth().
			digest("saurabh","saurabh1")
		.when().get("undefined/saurabh/saurabh")
		.then().assertThat().statusCode(200)
		.extract().response().asString();
	
	System.out.println(Response);
		
		
		
		

	}

}
