package Practice_APISK04.Practice_APISK04;

import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;
import io.restassured.RestAssured;
import static io.restassured.RestAssured.*;

import ReUsabaleFiles.RequestandResponseSpecifications;
import TestData.TestDataPayload;

public class RequestResponseSpecBuilderExamples {

	public static void main(String[] args) {
		
		RequestSpecification res=given().log().all().
				spec(RequestandResponseSpecifications.display1())
			.body(TestDataPayload.addName("John","Manager"));
		
		
	String Response=	res.when().post("/api/users").then().
			log().all().
spec(RequestandResponseSpecifications.display2()).extract().response().asString();

System.out.println(Response);
	
	
	
	
	
	
	
	
			
		
		
		

	}

}
