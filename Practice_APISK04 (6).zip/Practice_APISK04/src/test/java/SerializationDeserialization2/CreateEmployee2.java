package SerializationDeserialization2;

import static io.restassured.RestAssured.given;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import SerializationEx1.EmployeePOJO;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;

public class CreateEmployee2 {

	public static void main(String[] args) throws JsonProcessingException {
		
		EmployeeAddress empaddress=new EmployeeAddress();
		empaddress.setCity("Delhi");
		empaddress.setHousenum(34);
		empaddress.setStreet("PR lane");
		
		EmployeePOJO2 emp2=new EmployeePOJO2();
		emp2.setName("Robin");
		emp2.setJob("Manager");
		emp2.setPincode(713304);
		emp2.setSalary(90000.67);
		emp2.setEmpAddress(empaddress);
		
		ObjectMapper obj=new ObjectMapper();
		
		String empJSON=	obj.writerWithDefaultPrettyPrinter().writeValueAsString(emp2);
			
		
		RequestSpecification req=new RequestSpecBuilder()
				.setBaseUri("http://httpbin.org")
				.setContentType(ContentType.JSON).build();
		
		RequestSpecification respec=given().log().all().spec(req).body(empJSON);
		
		ResponseSpecification res=new ResponseSpecBuilder().
				expectStatusCode(200).
				expectContentType(ContentType.JSON).build();
		
		
		String Response= respec.when().post("post").then().log().all().spec(res)

				.extract().response().asString();
		
		System.out.println(Response);
		
		
		
		
		
		
		
		
		
		

	}

}
