package SerializationEx1;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;

import static io.restassured.RestAssured.*;

public class CreateEmployee {

	public static void main(String[] args) throws JsonProcessingException {
		
		
		EmployeePOJO emp=new EmployeePOJO();
		emp.setName("Robin");
		emp.setJob("Manager");
		emp.setPincode(713304);
		emp.setSalary(90000.67);
		
		ObjectMapper obj=new ObjectMapper();
		
	String empJSON=	obj.writerWithDefaultPrettyPrinter().writeValueAsString(emp);
		
	
	RequestSpecification req=new RequestSpecBuilder()
			.setBaseUri("http://httpbin.org")
			.setContentType(ContentType.JSON).build();
	
	RequestSpecification respec=given().log().all().spec(req).body(empJSON);
	
	ResponseSpecification res=new ResponseSpecBuilder().
			expectStatusCode(200).
			expectContentType(ContentType.JSON).build();
	
	
	String Response= respec.when().post("post").then().log().all().spec(res)

			.extract().response().asString();
	
	System.out.println(Response);
	
	
	////Deserailization
	
	
	EmployeePOJO empObj=obj.readValue(empJSON, EmployeePOJO.class);
	System.out.println();
	System.out.println("Doing Serilization");
	System.out.println(empObj.getJob());
	System.out.println(empObj.getName());
	System.out.println(empObj.getSalary());
	
//String JOBName=	emp.getJob();
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
			
	
	
	
	
		
		
		
		

	}

}
