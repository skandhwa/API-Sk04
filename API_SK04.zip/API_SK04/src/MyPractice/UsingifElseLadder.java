package MyPractice;

public class UsingifElseLadder {

	public static void main(String[] args) {
		
		int x=10,y=20,z=15,p=12;
		
		if(x>y && x>z && x>p)
		{
			System.out.println("x is maximum");
		}
		else if(y>x && y>z && y>p)
		{
			System.out.println("y is maximum");
		}
		else if(z>x && z>y && z>p)
		{
			System.out.println("z is maximum");
		}
		else
			
		{
			System.out.println("p is maximum");
		}
		
		
		

	}

}
