package MyPractice;

public class ReverseOfNumberJava {

	public static void main(String[] args) {
		
		int num=687;
		
		int t=num;
		
		int rev=0;
		
		while(num!=0)///45!=0//4!=0//0!=0
		{
			int r=num%10;//r=6/// r=5 //r=4%10=4
			rev=rev*10+r;//rev=0*10+6=6///rev=6*10+5=65///rev=65*10+4=654
			num=num/10;///num=num/10=456/10=45//num=45/10=4//num=4/10=0
		}
		
		System.out.println("reverse of  number is "+rev);
		
		if(t==rev)
		{
			System.out.println("it is palindrome");
		}
		else
		{
			System.out.println("Not palindrome");
		}
		

	}

}
