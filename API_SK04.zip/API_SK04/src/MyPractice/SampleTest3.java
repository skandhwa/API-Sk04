package MyPractice;

public class SampleTest3 {

	public static void main(String[] args) {
		
		

	}

}
