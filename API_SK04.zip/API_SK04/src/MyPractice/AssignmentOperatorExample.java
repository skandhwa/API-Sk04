package MyPractice;

public class AssignmentOperatorExample {

	public static void main(String[] args) {
		
		int a=20;
		int c=30;
		
		a+=10;
		//a=a+10;
		
		a*=5;//a=a*5
		
	int z=	c%=4;//c=c%4
	System.out.println(z);
		
		
		
		

	}

}
