package MyPractice;

class C
{
	int id;
	String name;
	String address;
	
	
	C(int i,String n)
	{
		
		id=i;
		name=n;
		
	}
	
	C(int j,String n1,String n2)
	{
		id=j;
		name=n1;
		address=n2;
		
	}
	
	
	
	
	void display()
	{
		System.out.println(id+" "+name+" "+address);
	}
	
}

public class ParameterizedConstructor {
	
	public static void main(String[] args)
	{
	
	C obj=new C(23,"Saurabh");
	obj.display();
	
	C obj1=new C(45,"Gaurabh","Kolkata");
	obj1.display();
	
	}
	
	

}
