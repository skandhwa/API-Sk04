package MyPractice;

public class ifelseloopExample {

	public static void main(String[] args) {
		
		int x=5;
		int y=10;
		int z=20;
		
		if(x<y && y<=z/2 && z<=y)//5<10, 10<=10, 20>=10
		{
			System.out.println("true");
		}
		else
		{
			System.out.println("false");
		}
		
		

	}

}
