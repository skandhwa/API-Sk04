package MyPractice;

public class RelationalOperatorEx {

	public static void main(String[] args) {
		
		int a=20;
		int b=42/2;
		
//		if(a<=b)///10<=15
//		{
//			System.out.println("true");
//		}
//		else
//		{
//			System.out.println("false");
//		}
		
		
		if(a==b)
		{
			System.out.println("a and b are equal");
		}
		else
		{
			System.out.println("a and b are not equal");
		}
		
		

	}

}
