package MyPractice;

public class LogicalNOTOperators {

	public static void main(String[] args) {
		
		int a=10;
		
		int b=30/2;
		
		if(a!=b)//
		{
			System.out.println("true");
		}
		else
		{
			System.out.println("false");
		}
		

	}

}
