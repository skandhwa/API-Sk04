package MyPractice;

public class TernaryOperator {

	public static void main(String[] args) {
		
		int a=350;
		int b=50;
		int c=40;
		
		int max;
		
		//max= (a>b)?a:b;
		
		max=(a>b  ?  (a>c?a:c):  (b>c?b:c));
		
		System.out.println(max);
		

	}

}
