package MyPractice;

public class MethodExample2 {

	public static void main(String[] args) {
		
		
		for(int i=0;i<3;i++)//i=0,0<3//i=1,1<3
		{
			for(int j=0;j<3;j++)//j=1,1<3
			{
				System.out.println(i+" "+j);///0..0//0..1//0..2//1..1
			}
		}
		
		

	}

}
