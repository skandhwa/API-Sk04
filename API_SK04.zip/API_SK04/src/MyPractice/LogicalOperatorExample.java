package MyPractice;

public class LogicalOperatorExample {

	public static void main(String[] args) {
		
		int a=20;
		int b=10;
		int c=15;
		
		///Logical And Operators
		
//		if(a>b && a>c && b<c)
//		{
//			System.out.println("true");
//		}
//		else
//		{
//			System.out.println("false");
//		}
		
		
		////Logical OR operator
		
		
		if(a<b || a<c || b<c)///20<10
			{
				System.out.println("true");
			}
			else
			{
				System.out.println("false");
			}
		

	}

}
