package MyPractice;

public class DataTypes1 {

	public static void main(String[] args) {

         boolean flag=false;
         
         byte x=-14;
         
         short y=1255; ///-32768 to 32767
         
         int p=1232131212;
         
         long j=2312321312231321312L;
         
         float z=321322131231231231123123123123321.123213212213123123213123123123212131321f;
         
         double m=2132132132131232132132.1232131232132131231221;
         
         char q='Z';
         
		
		
		

	}

}
