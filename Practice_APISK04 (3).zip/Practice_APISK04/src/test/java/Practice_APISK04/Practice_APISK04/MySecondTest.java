package Practice_APISK04.Practice_APISK04;

import static io.restassured.RestAssured.given;

import org.testng.Assert;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;

public class MySecondTest {

	public static void main(String[] args) {
		
		int Actual_page=2;
		String Actual_Email="michael.lawson@reqres.in";
		
		RestAssured.baseURI="https://reqres.in";
		
		String Response=		given().log().all().queryParam("page","2").
				queryParam("page","2")
				.
				
				
				
				when().get("api/users")
				.then().log().all().extract().response().asString();

		System.out.println(Response);
		
		JsonPath js=new JsonPath(Response);
		
	int Expected_Page=	js.getInt("page");
	
	String Expected_email=js.getString("data[0].email");
	
	Assert.assertEquals(Actual_page,Expected_Page);
	Assert.assertEquals(Actual_Email,Expected_email);
	
	
	System.out.println("Test Case passed");
	
	
	
	
	
		
		
		
		

	}

}
