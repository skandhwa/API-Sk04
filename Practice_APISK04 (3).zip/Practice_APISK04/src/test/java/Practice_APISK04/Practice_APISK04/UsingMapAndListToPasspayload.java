package Practice_APISK04.Practice_APISK04;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;

import static io.restassured.RestAssured.*;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.testng.Assert;

public class UsingMapAndListToPasspayload {

	public static void main(String[] args) {
		
		RestAssured.baseURI="https://httpbin.org";
		Map<String,Object> mp=new LinkedHashMap<String,Object>();
		
		mp.put("name","Rohan");
		mp.put("id",8976);
		mp.put("isActive",'Y');
		mp.put("salary", 7899.5f);
		
Map<String,Object> mp2=new LinkedHashMap<String,Object>();
		
		mp2.put("name","Sohan");
		mp2.put("id",6976);
		mp2.put("isActive",'Y');
		mp2.put("salary", 6899.5f);
		
Map<String,Object> mp3=new LinkedHashMap<String,Object>();
		
		mp3.put("name","Mohan");
		mp3.put("id",2976);
		mp3.put("isActive",'Y');
		mp3.put("salary", 9899.5f);
		
		List<Map> li=new ArrayList<Map>();
		li.add(mp);
		li.add(mp2);
		li.add(mp3);
		
		
	String Response=	given().log().all().headers("Content-Type","application/json")
		.body(li).when().post("post")
		.then().log().all().
		assertThat().statusCode(200).extract().response().asString();
		
	System.out.println();
	System.out.println();
	System.out.println(Response);
	
	JsonPath js=new JsonPath(Response);
String name=	js.getString("json[0].name");
System.out.println(name);

Assert.assertEquals("Rohan", name);

System.out.println("Test Case passed");
		
		
		
		
		

	}

}
