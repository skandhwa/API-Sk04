package TestData;

public class TestDataPayload {
	
	public static String addName(String name1,String job)
	{
		String name="{\r\n"
				+ "    \"name\": \""+name1+"\",\r\n"
				+ "    \"job\": \""+job+"\"\r\n"
				+ "}";
		
		return name;
		
	}
	
	public static String addBook(String i,String a)
	{
		String bookdetails="{\r\n"
				+ "\r\n"
				+ "\"name\":\"Learn Appium Automation with Java\",\r\n"
				+ "\"isbn\":\""+i+"\",\r\n"
				+ "\"aisle\":\""+a+"\",\r\n"
				+ "\"author\":\"John foe\"\r\n"
				+ "}\r\n"
				+ "";
		
		return bookdetails;
	}
	
	
	

}
