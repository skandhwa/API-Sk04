package TestData;

public class TestDataPayload {
	
	public static String addName(String name1,String job)
	{
		String name="{\r\n"
				+ "    \"name\": \""+name1+"\",\r\n"
				+ "    \"job\": \""+job+"\"\r\n"
				+ "}";
		
		return name;
		
	}

}
