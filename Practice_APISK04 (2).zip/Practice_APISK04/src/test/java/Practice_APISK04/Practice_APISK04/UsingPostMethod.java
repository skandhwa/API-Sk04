package Practice_APISK04.Practice_APISK04;

import io.restassured.RestAssured;
import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

import TestData.TestDataPayload;

public class UsingPostMethod {

	public static void main(String[] args) {
		
		RestAssured.baseURI="https://reqres.in";
		
String Response=		given().log().all().headers("Content-Type","application/json")
		.body(TestDataPayload.addName("Tom","QA manager"))
		
		.when().post("api/users")
		.then().log().all().assertThat().statusCode(201)
		
		.body("name", equalTo("Tom"))////Add hamcrest Matcher 
		
		
		.extract().response().asString();

System.out.println(Response);







		
		
		
		
		

	}

}
