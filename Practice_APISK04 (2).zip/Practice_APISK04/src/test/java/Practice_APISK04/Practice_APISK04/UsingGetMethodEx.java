package Practice_APISK04.Practice_APISK04;

public class UsingGetMethodEx {

	public static void main(String[] args) {
		

	}

}
